This is a clean readme file.
Nothing suspicious here.
